from torchvision import transforms
from nts_net.model import ntsnet
from nts_net.model import ProposalNet
from nts_net.model import attention_net
import torch
#import torchvision.models as models
import urllib
from PIL import Image

transform_test = transforms.Compose([
    transforms.Resize((600, 600), Image.BILINEAR),
    transforms.CenterCrop((448, 448)),
    # transforms.RandomHorizontalFlip(),  # only if train
    transforms.ToTensor(),
    transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
])

def ntsnet(pretrained=False,**kwargs):
    net = attention_net(**kwargs)
    if pretrained:
       from bird_classes import bird_classes
       net.bird_classes = bird_classes
       checkpoint = 'models/nts_net_cub200.pt'
       state_dict = torch.load(checkpoint)
       net.load_state_dict(state_dict)
    return net


#model = torch.hub.load('nicolalandro/ntsnet-cub200', 'ntsnet', pretrained=True, **{'topN': 6, 'device':'cpu', 'num_classes': 200})

model = ntsnet(pretrained=True,**{'topN': 6, 'device':'cpu', 'num_classes': 200})
model.eval()

#url = 'https://raw.githubusercontent.com/nicolalandro/ntsnet-cub200/master/images/nts-net.png'
#local_image = '/home/oyj/Downloads/ba2.jpg'
local_image = '/home/oyj/Downloads/ba.jpg'
local_image = '/home/oyj/Downloads/sa.jpg'
local_image = '/home/oyj/Downloads/pa.jpg'
#img = Image.open(urllib.request.urlopen(url))
img = Image.open(local_image)
scaled_img = transform_test(img)
torch_images = scaled_img.unsqueeze(0)

def find_bird():
    with torch.no_grad():
      top_n_coordinates, concat_out, raw_logits, concat_logits, part_logits, top_n_index, top_n_prob = model(torch_images)
    
      _, predict = torch.max(concat_logits, 1)
      pred_id = predict.item()
    
    #print('bird class:', model.bird_classes[pred_id])
      return ('bird class:', model.bird_classes[pred_id])

from fastapi import FastAPI
import uvicorn
from bird_predict import find_bird
app = FastAPI()

@app.post('/predict')
def predict():
    return find_bird()
